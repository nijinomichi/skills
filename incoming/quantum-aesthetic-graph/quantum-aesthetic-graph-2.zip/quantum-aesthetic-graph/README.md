# quantum-aesthetic-graph

AI Skill package: structure human ambiguity into **YAML ART** without
false scientific precision.

## Assessment (why this shape)

| Use | Usefulness |
|---|---|
| YAML ART format | high |
| AI Skill reference / ontology | high |
| Direct skill-spec dump of full artwork YAML | medium → **avoided** |
| Main strength | worldview, ethics, graph vocab, metaphor/science boundary |
| Main risk mitigated | metrics looking more scientific than supported |

**Recommended use (implemented here):**

> Preserve the dense artwork YAML as ART/reference source,  
> then derive a smaller executable AI Skill from it.

## Layout

```text
skills/quantum-aesthetic-graph/
├── SKILL.md
├── README.md
├── LICENSE.txt
├── ASSESSMENT.md
├── references/
│   └── quantum-trust-graph-art.yaml
├── schemas/
│   └── graph-art.schema.yaml
└── templates/
    └── artwork.yaml
```

## Three surfaces

- **art_surface** — humans read
- **semantic_surface** — AI reads
- **execution_surface** — tools/skill execute

## Quick start for agents

1. Read `SKILL.md`
2. Load `references/quantum-trust-graph-art.yaml` as ontology
3. Emit new works from `templates/artwork.yaml`
4. Validate against `schemas/graph-art.schema.yaml` invariants

## Status

- `status: production-ready`
- `canonical: true` for this skill package
