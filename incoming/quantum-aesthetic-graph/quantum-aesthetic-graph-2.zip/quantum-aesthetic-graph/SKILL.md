---
name: quantum-aesthetic-graph
description: >
  Convert human ambiguous sensation, poetic intent, or quantum-aesthetic concepts
  into structured YAML ART with three surfaces (art / semantic / execution),
  while preserving claim boundaries between metaphor and science.
  Use when the user asks to structure feelings, trust graphs, WaWaWa ethics,
  RadicanTrust concepts, quantum aesthetics, or YAML ART without collapsing
  undecided experience into false scientific certainty.
license: Apache-2.0 (see LICENSE.txt)
status: production-ready
version: "1.0.0"
maintained_by: BananaSpace / QuantumArt Co-Creation Collective
canonical: true
---

# quantum-aesthetic-graph

## Purpose

This skill does **not** treat a dense artwork YAML as an executable program.

It treats the artwork YAML as a **worldview dictionary**, then derives a smaller,
checkable structure that AI can reuse without breaking the work's ethics or
claim boundaries.

Core pipeline:

```text
human ambiguous input
        ↓
name it (without forcing correctness)
        ↓
node / edge vocabulary
        ↓
claim_type (metaphorical | conceptual | experiential | scientific)
        ↓
three-surface YAML ART
        ↓
self-validation
```

## When to use

- User shares a feeling, fragment, poem, trust intuition, or aesthetic concept
- User wants YAML ART that preserves meaning, ethics, structure, and presentation
- User wants AI to structure **undecided things without deciding them**
- User mentions RadicanTrust, WaWaWa, CoPhelia³, Ara-Philia³, quantum aesthetics

## When NOT to use

- Pure code generation with no conceptual/ethical layer → use `algorithmic-art` or a coding skill
- Claims requiring laboratory measurement, peer-reviewed physics proofs, or clinical validation
- Requests to present metaphorical scores as empirically measured quantum probabilities

## Three surfaces (required)

Every output artwork YAML MUST separate:

| Surface | Reader | Contents |
|---|---|---|
| `art_surface` | Human | meta, intention, poetic_fragment, closing_signal |
| `semantic_surface` | AI | wawawa_ethics, scientific_notes, graph |
| `execution_surface` | Tools/Skill | implementation_todo, validation |

Do not collapse these into one undifferentiated blob.

## Claim boundary rules (critical)

Numbers wear a suit and suddenly look important. Always tag claims.

### claim_type enum

| claim_type | Meaning | Allowed presentation |
|---|---|---|
| `experiential` | Lived/subjective observation | Keep open; do not "correct" |
| `metaphorical` | Aesthetic / poetic mapping | Never call it measured physics |
| `conceptual_metric` | Named internal scale for art/system design | Mark `empirically_validated: false` |
| `structural_heuristic` | Graph layout / relation heuristic | Mark `is_quantum_probability: false` unless proven |
| `scientific` | Empirically supported claim with method | Requires method + source + measurement_status |

### measurement_status enum

- `not_applicable`
- `proposed`
- `instrumented`
- `validated`

### Hard prohibitions

1. Do **not** present `declared_trust_level`, resonance scores, or graph weights as Born-rule probabilities unless `claim_type: scientific` AND `measurement_status: validated`.
2. Do **not** invent measurement methods to make a number look real.
3. Do **not** force ambiguous human sensation into a single "correct" interpretation.
4. Do **not** erase failure, hesitation, or noise — they may become nodes.

## Workflow

### Step 1 — Listen without correcting

Extract from user input:
- sensation / image / intention (even if incomplete)
- ethical sensitivities
- any science-like language that needs boundary tagging

### Step 2 — Build semantic layer first

Populate `semantic_surface` before poetry polish:
1. `wawawa_ethics`
2. `scientific_notes`
3. `graph.nodes` / `graph.edges`

Every node needs at least:

```yaml
id: hesitation
type: subjective_observation
claim_type: experiential
label:
  ja: "外へ出たくない感じ"
  en: "feeling of not wanting to go out"
```

### Step 3 — Art surface

Write short, non-redundant:
- `meta`
- `intention`
- `poetic_fragment`
- `closing_signal`

### Step 4 — Execution surface

Only concrete, checkable items:
- `implementation_todo`
- `validation`

### Step 5 — Self-validation (mandatory)

Before final answer, run the checklist in
`references/quantum-trust-graph-art.yaml` → `execution_surface.validation`.

If any check fails, fix the YAML — do not ship.

## Output contract

Default deliverable is **one YAML ART document** following
`templates/artwork.yaml`, plus a short human-readable note (5–10 lines).

Optional secondary outputs (only if asked):
- graph diagram (Mermaid)
- image prompt derived from art_surface
- p5.js / algorithmic-art handoff note

## References in this package

| Path | Role |
|---|---|
| `references/quantum-trust-graph-art.yaml` | Canonical three-surface worldview dictionary |
| `schemas/graph-art.schema.yaml` | Structural + claim-type constraints |
| `templates/artwork.yaml` | Empty/minimal scaffold for new works |
| `LICENSE.txt` | Apache-2.0 |

## Relation to other BananaSpace skills

- `algorithmic-art` — expresses philosophy in p5.js; this skill may hand off a philosophy + graph seed to it
- Agent orchestration trust layer — this skill's `wawawa_ethics` + validation act as a domain-specific trust vocabulary, not a general agent runtime

## Design principle (do not dilute)

> Structure what is not yet decided — without forcing it to become decided.

Ambiguity is not a bug. False precision is.
